 <!-- CSS -->
 <link rel="stylesheet" type="text/css" href="../assets/css/home.css">
<nav>
        <div class="wrapper">
            <div class="logo"><a href="home.php" style="text-decoration:none;color:white;">TokoSebelah</a></div>
            <div class="menu">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="profile.php"><i class="far fa-user-circle"></i> Account</a></li>
                    <li><a href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a></li>
                </ul>
            </div>
        </div>
    </nav>
