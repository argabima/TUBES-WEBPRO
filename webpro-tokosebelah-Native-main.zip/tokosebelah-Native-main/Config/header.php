 <!-- CSS -->
 <link rel="stylesheet" type="text/css" href="assets/css/home.css">
<nav>
        <div class="wrapper">
            <div class="logo"><a href="home.php" style="text-decoration:none;color:white;">TokoSebelah</a></div>
            <div class="menu">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="gallery.php">Gallery</a></li>
                    <li><a href="contact.php">Contact</a></li>
                    <li><a href="./User/login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>
