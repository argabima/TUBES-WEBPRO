# tokosebelah-Native
- [x] PHP 
- [x] AJAX QUERY
- [x] Bootstrap
- [x] HTML
- [x] Mysql 

## Developed By
# Kelompok 3
~ Arga Bimantara - [Arga Bimantara](https://github.com/argabima)<br>
~ Audia Shafarina Justy - [Audia Shafarina Justy](https://github.com/odiee12/front-end.git)<br>
~ Bagas Alfito Prismawan - [Bagas Mahier](https://github.com/BagasMahier12a)<br>
~ Ditya Ilmi Rizqi - [Ditya Ilmi Rizqi](https://github.com/dityailmir/TS_front-end)<br>
~ Fitri Raihan Safira Sinaga - [Fitri Raihan Safira Sinaga](https://www.figma.com/team_invite/redeem/e2CBI3IqlebaEofx9x6xHF)<br>
~ Sultan Kautsar - [Sultan Kautsar](https://github.com/bydzen)<br>
